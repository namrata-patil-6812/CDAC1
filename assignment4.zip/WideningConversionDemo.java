package assignment4;
public class WideningConversionDemo {
    public static void main(String[] args) {
 
        int intValue = 42;
         double doubleValue = intValue;
         System.out.println("The integer value: " + intValue);
        System.out.println("The converted double value: " + doubleValue);
    }
}

