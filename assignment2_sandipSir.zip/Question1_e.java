package assignment2_sandipSir;

public class Question1_e {

	public static void main(String[] args) {
		Boolean status = true;
		boolean a = Boolean.valueOf(status);
		System.out.println(a);
		
		
		
	}



}
