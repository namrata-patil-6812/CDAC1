package assignment2_sandipSir;

public class Question1_g {
public static void main(String[] args) {
	boolean a = true;
	String s = Boolean.toString(a);
	System.out.println(s);
}
}
