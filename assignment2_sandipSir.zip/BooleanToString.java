package assignment2_sandipSir;

public class BooleanToString {

	
	public static void main(String[] args) {
		boolean status = true ;
		String  a = Boolean.toString(status);
		System.out.println(a);
	}
	
}
