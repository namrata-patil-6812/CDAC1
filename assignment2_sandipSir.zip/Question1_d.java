package assignment2_sandipSir;

public class Question1_d {

	public static void main(String[] args) {
		String strStatus = "10";
		Boolean a = Boolean.parseBoolean(strStatus);
		System.out.println(a);
		
		
		
	}

}
