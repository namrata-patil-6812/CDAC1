package assignment2_sandipSir;

public class StringToBoolean {
	public static void main(String[] args) {
		String strStatus = "true";
		Boolean a = Boolean.parseBoolean(strStatus);
		System.out.println(a);
	}

}
