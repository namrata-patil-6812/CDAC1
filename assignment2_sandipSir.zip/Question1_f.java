package assignment2_sandipSir;

public class Question1_f {

	public static void main(String[] args) {
		
		
		 String s = "4";
		 Boolean a = Boolean.valueOf(s);
		 System.out.println(a);
	}

}
